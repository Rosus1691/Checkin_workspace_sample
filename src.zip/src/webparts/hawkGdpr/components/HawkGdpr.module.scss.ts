/* tslint:disable */
require("./HawkGdpr.module.css");
const styles = {
  hawkGdpr: 'hawkGdpr_8ce32fa0',
  container: 'container_8ce32fa0',
  row: 'row_8ce32fa0',
  column: 'column_8ce32fa0',
  'ms-Grid': 'ms-Grid_8ce32fa0',
  title: 'title_8ce32fa0',
  subTitle: 'subTitle_8ce32fa0',
  description: 'description_8ce32fa0',
  button: 'button_8ce32fa0',
  label: 'label_8ce32fa0'
};

export default styles;
/* tslint:enable */