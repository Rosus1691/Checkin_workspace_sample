import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IHawkGdprProps {
  description: string;
  context: WebPartContext;
}
