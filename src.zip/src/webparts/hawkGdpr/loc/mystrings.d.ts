declare interface IHawkGdprWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'HawkGdprWebPartStrings' {
  const strings: IHawkGdprWebPartStrings;
  export = strings;
}
